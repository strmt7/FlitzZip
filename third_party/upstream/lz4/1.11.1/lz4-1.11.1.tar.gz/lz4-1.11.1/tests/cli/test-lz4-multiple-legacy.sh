#!/bin/sh

FPREFIX="tmp-lml"

set -e

remove () {
    rm $FPREFIX*
}

trap remove EXIT

set -x

datagen -s1        > "${FPREFIX}1" 2> $FPREFIX-trash
datagen -s2 -g100K > "${FPREFIX}2" 2> $FPREFIX-trash
datagen -s3 -g200K > "${FPREFIX}3" 2> $FPREFIX-trash
# compress multiple files using legacy format: one .lz4 per source file
lz4 -f -l -m $FPREFIX*
test -f ${FPREFIX}1.lz4
test -f ${FPREFIX}2.lz4
test -f ${FPREFIX}3.lz4
# decompress multiple files compressed using legacy format: one output file per .lz4
mv ${FPREFIX}1 ${FPREFIX}1-orig
mv ${FPREFIX}2 ${FPREFIX}2-orig
mv ${FPREFIX}3 ${FPREFIX}3-orig
lz4 -d -f -m $FPREFIX*.lz4
lz4 -l -d -f -m $FPREFIX*.lz4 # -l mustn't impact -d option
cmp ${FPREFIX}1 ${FPREFIX}1-orig   # must be identical
cmp ${FPREFIX}2 ${FPREFIX}2-orig
cmp ${FPREFIX}3 ${FPREFIX}3-orig
# compress multiple files into stdout using legacy format
cat ${FPREFIX}1.lz4 ${FPREFIX}2.lz4 ${FPREFIX}3.lz4 > $FPREFIX-concat1
rm -f $FPREFIX*.lz4
lz4 -l -m ${FPREFIX}1 ${FPREFIX}2 ${FPREFIX}3 -c > $FPREFIX-concat2
test ! -f ${FPREFIX}1.lz4  # must not create .lz4 artefact
cmp $FPREFIX-concat1 $FPREFIX-concat2  # must be equivalent
# # # decompress multiple files into stdout using legacy format
rm $FPREFIX-concat1 $FPREFIX-concat2
lz4 -l -f -m ${FPREFIX}1 ${FPREFIX}2 ${FPREFIX}3   # generate .lz4 to decompress
cat ${FPREFIX}1 ${FPREFIX}2 ${FPREFIX}3 > ${FPREFIX}-concat1   # create concatenated reference
rm ${FPREFIX}1 ${FPREFIX}2 ${FPREFIX}3
lz4 -d -m ${FPREFIX}1.lz4 ${FPREFIX}2.lz4 ${FPREFIX}3.lz4 -c > $FPREFIX-concat2
lz4 -d -l -m ${FPREFIX}1.lz4 ${FPREFIX}2.lz4 ${FPREFIX}3.lz4 -c > $FPREFIX-concat2 # -l mustn't impact option -d
test ! -f ${FPREFIX}1  # must not create file artefact
cmp $FPREFIX-concat1 $FPREFIX-concat2  # must be equivalent
# # # compress multiple files, one of which is absent (must fail)
rm -f $FPREFIX-concat2.lz4
lz4 -f -l -m $FPREFIX-concat1 notHere-legacy $FPREFIX-concat2 && exit 1 # must fail : notHere-legacy not present
test -f $FPREFIX-concat2.lz4 # notHere was a non-blocking error, concat2.lz4 should be present
# test multiple legacy files without writing decoded content
lz4 -tm $FPREFIX-concat1.lz4 $FPREFIX-concat2.lz4 > $FPREFIX-test-output
test ! -s $FPREFIX-test-output
# legacy frame ended by a zero block size (Linux kernel), followed by another frame
cat ${FPREFIX}1.lz4 > $FPREFIX-zero.lz4
printf '\000\000\000\000' >> $FPREFIX-zero.lz4
cat ${FPREFIX}2.lz4 >> $FPREFIX-zero.lz4
lz4 -dc $FPREFIX-zero.lz4 > $FPREFIX-zero
cat ${FPREFIX}1-orig ${FPREFIX}2-orig | cmp - $FPREFIX-zero
lz4 --list $FPREFIX-zero.lz4
# --list : a block of incompressible data is larger than 8 MB, as accepted by the decoder
datagen -g9M -P0 | lz4 -l -c > $FPREFIX-noise.lz4
lz4 -t $FPREFIX-noise.lz4
lz4 --list $FPREFIX-noise.lz4
# --list : a truncated block is invalid, as for -t
head -c $(( $(wc -c < ${FPREFIX}2.lz4) - 1 )) ${FPREFIX}2.lz4 > $FPREFIX-trunc.lz4
lz4 -t $FPREFIX-trunc.lz4 && exit 1
lz4 --list $FPREFIX-trunc.lz4 && exit 1
# --list : an empty input is compressed into a frame without block
datagen -g0 | lz4 -l -c > $FPREFIX-empty.lz4
cat $FPREFIX-empty.lz4 ${FPREFIX}1.lz4 > $FPREFIX-empty2.lz4
lz4 -t $FPREFIX-empty.lz4
lz4 -t $FPREFIX-empty2.lz4
lz4 --list $FPREFIX-empty.lz4
lz4 --list $FPREFIX-empty2.lz4
true
